import MatchCard from './MatchCard';
import Badge from './Badge';

interface Match {
  fixture: any;
  league: any;
  teams: any;
  goals: any;
  score: any;
}

interface MatchesGroupProps {
  title: string;
  matches: Match[];
  icon?: React.ReactNode;
}

export default function MatchesGroup({ title, matches, icon }: MatchesGroupProps) {
  if (matches.length === 0) return null;

  return (
    <div className="mb-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-[#1F1F1F] rounded-xl shadow-2xl border border-gray-700 overflow-hidden card-glow">
        <div className="gradient-accent px-6 py-4">
          <div className="flex items-center gap-3">
            {icon}
            <h2 className="text-2xl font-bold text-white">{title}</h2>
            <Badge variant="secondary" className="mr-auto bg-white/95 text-gray-800 hover:bg-white font-semibold">
              {matches.length} مباراة
            </Badge>
          </div>
        </div>
        <div className="p-6 bg-[#1A1A1A]">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {matches.map((match) =>
            <MatchCard
              key={match.fixture.id}
              fixture={match.fixture}
              league={match.league}
              teams={match.teams}
              goals={match.goals}
              status={match.fixture.status}
              date={match.fixture.date} />

            )}
          </div>
        </div>
      </div>
    </div>);

}