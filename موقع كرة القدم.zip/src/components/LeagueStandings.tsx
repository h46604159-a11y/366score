import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';

interface Standing {
  rank: number;
  team: {
    id: number;
    name: string;
    logo: string;
  };
  points: number;
  goalsDiff: number;
  all: {
    played: number;
    win: number;
    draw: number;
    lose: number;
  };
}

interface LeagueStandingsProps {
  standings: Standing[];
}

export default function LeagueStandings({ standings }: LeagueStandingsProps) {
  if (!standings || standings.length === 0) {
    return (
      <div className="text-center py-8 text-gray-400">
        لا تتوفر بيانات الترتيب حالياً
      </div>);

  }

  const getPositionColor = (rank: number) => {
    if (rank <= 4) return 'bg-emerald-500/10 border-r-4 border-emerald-400';
    if (rank <= 6) return 'bg-cyan-500/10 border-r-4 border-cyan-400';
    if (rank >= standings.length - 2) return 'bg-red-500/10 border-r-4 border-red-400';
    return '';
  };

  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="bg-[#2A2A2A] border-b border-gray-700">
            <TableHead className="text-center font-semibold w-12 text-gray-200">#</TableHead>
            <TableHead className="text-right font-semibold text-gray-200">الفريق</TableHead>
            <TableHead className="text-center font-semibold w-16 text-gray-200">لعب</TableHead>
            <TableHead className="text-center font-semibold w-16 text-gray-200">فوز</TableHead>
            <TableHead className="text-center font-semibold w-16 text-gray-200">تعادل</TableHead>
            <TableHead className="text-center font-semibold w-16 text-gray-200">خسارة</TableHead>
            <TableHead className="text-center font-semibold w-20 text-gray-200">فرق الأهداف</TableHead>
            <TableHead className="text-center font-semibold w-20 gradient-accent text-white">النقاط</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {standings.map((standing) =>
          <TableRow
            key={standing.team.id}
            className={`hover:bg-[#2A2A2A] transition-colors border-b border-gray-800 ${getPositionColor(standing.rank)}`}>

              <TableCell className="text-center font-bold text-white">
                {standing.rank}
              </TableCell>
              <TableCell className="text-right">
                <div className="flex items-center justify-end gap-2">
                  <span className="font-medium text-white">{standing.team.name}</span>
                  <img
                  src={standing.team.logo}
                  alt={standing.team.name}
                  className="w-6 h-6 object-contain" />

                </div>
              </TableCell>
              <TableCell className="text-center text-gray-300">
                {standing.all.played}
              </TableCell>
              <TableCell className="text-center text-emerald-400 font-medium">
                {standing.all.win}
              </TableCell>
              <TableCell className="text-center text-gray-300">
                {standing.all.draw}
              </TableCell>
              <TableCell className="text-center text-red-400 font-medium">
                {standing.all.lose}
              </TableCell>
              <TableCell className="text-center font-medium text-gray-200">
                {standing.goalsDiff > 0 ? '+' : ''}{standing.goalsDiff}
              </TableCell>
              <TableCell className="text-center font-bold text-lg text-white bg-gradient-to-r from-emerald-400/20 to-cyan-400/20">
                {standing.points}
              </TableCell>
            </TableRow>
          )}
        </TableBody>
      </Table>
    </div>);

}