import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Clock, Circle } from 'lucide-react';

interface Match {
  fixture: any;
  league: any;
  teams: any;
  goals: any;
  score: any;
}

interface LaLigaTableProps {
  title: string;
  matches: Match[];
  icon?: React.ReactNode;
}

export default function LaLigaTable({ title, matches, icon }: LaLigaTableProps) {
  if (matches.length === 0) return null;

  const getMatchTime = (date: string) => {
    return new Date(date).toLocaleTimeString('ar-SA', {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true
    });
  };

  const getStatusBadge = (status: any) => {
    const { short, elapsed } = status;
    const isLive = ['1H', '2H', 'HT', 'ET', 'P'].includes(short);
    const isFinished = ['FT', 'AET', 'PEN'].includes(short);
    const isScheduled = ['NS', 'TBD'].includes(short);

    if (isLive) {
      return (
        <Badge variant="destructive" className="animate-pulse">
          <Circle className="w-2 h-2 mr-1 fill-current" />
          مباشر {elapsed ? `${elapsed}'` : ''}
        </Badge>);

    }
    if (isFinished) {
      return <Badge variant="secondary">انتهت</Badge>;
    }
    if (isScheduled) {
      return <Badge variant="outline">لم تبدأ</Badge>;
    }
    return <Badge variant="secondary">{status.long}</Badge>;
  };

  return (
    <div className="mb-8 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-[#1F1F1F] rounded-xl shadow-2xl border border-gray-700 overflow-hidden card-glow">
        <div className="gradient-accent px-6 py-4">
          <div className="flex items-center gap-3">
            {icon}
            <h2 className="text-2xl font-bold text-white">{title}</h2>
            <Badge variant="secondary" className="mr-auto bg-white/95 text-gray-800 hover:bg-white font-semibold">
              {matches.length} مباراة
            </Badge>
          </div>
        </div>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="bg-[#262626] border-b border-gray-700">
                <TableHead className="text-center font-semibold text-gray-200">الوقت</TableHead>
                <TableHead className="text-right font-semibold text-gray-200">الفريق المضيف</TableHead>
                <TableHead className="text-center font-semibold text-gray-200">النتيجة</TableHead>
                <TableHead className="text-right font-semibold text-gray-200">الفريق الضيف</TableHead>
                <TableHead className="text-center font-semibold text-gray-200">الحالة</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {matches.map((match) => {
                const isLive = ['1H', '2H', 'HT', 'ET', 'P'].includes(match.fixture.status.short);
                const isScheduled = ['NS', 'TBD'].includes(match.fixture.status.short);

                return (
                  <TableRow key={match.fixture.id} className="hover:bg-[#2A2A2A] transition-colors border-b border-gray-800">
                    <TableCell className="text-center">
                      <div className="flex items-center justify-center gap-1 text-sm text-gray-300">
                        <Clock className="w-4 h-4" />
                        {getMatchTime(match.fixture.date)}
                      </div>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-2">
                        <span className="font-medium text-white">{match.teams.home.name}</span>
                        <img
                          src={match.teams.home.logo}
                          alt={match.teams.home.name}
                          className="w-8 h-8 object-contain" />

                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      {isScheduled ?
                      <span className="text-gray-500 text-sm font-semibold">VS</span> :

                      <div className={`text-xl font-bold ${isLive ? 'text-emerald-400' : 'text-gray-200'}`}>
                          {match.goals.home ?? 0} - {match.goals.away ?? 0}
                        </div>
                      }
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-start gap-2">
                        <img
                          src={match.teams.away.logo}
                          alt={match.teams.away.name}
                          className="w-8 h-8 object-contain" />

                        <span className="font-medium text-white">{match.teams.away.name}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-center">
                      {getStatusBadge(match.fixture.status)}
                    </TableCell>
                  </TableRow>);

              })}
            </TableBody>
          </Table>
        </div>
      </div>
    </div>);

}