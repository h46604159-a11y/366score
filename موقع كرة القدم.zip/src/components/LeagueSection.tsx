import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import LeagueMatchesTable from './LeagueMatchesTable';
import LeagueStandings from './LeagueStandings';

interface Match {
  fixture: any;
  league: any;
  teams: any;
  goals: any;
  score: any;
}

interface Standing {
  rank: number;
  team: {
    id: number;
    name: string;
    logo: string;
  };
  points: number;
  goalsDiff: number;
  all: {
    played: number;
    win: number;
    draw: number;
    lose: number;
  };
}

interface LeagueSectionProps {
  leagueId: string;
  leagueName: string;
  leagueLogo: string;
  matches: Match[];
  standings: Standing[];
  isOpen?: boolean;
}

export default function LeagueSection({
  leagueId,
  leagueName,
  leagueLogo,
  matches,
  standings,
  isOpen = false
}: LeagueSectionProps) {
  return (
    <div className="mb-6 animate-in fade-in slide-in-from-bottom-4 duration-500">
      <div className="bg-[#1F1F1F] rounded-xl shadow-2xl border border-gray-700 overflow-hidden card-glow card-glow-hover transition-all duration-300">
        <div className="gradient-accent px-6 py-4">
          <div className="flex items-center gap-3">
            <img
              src={leagueLogo}
              alt={leagueName}
              className="w-10 h-10 object-contain bg-white rounded-full p-1" />
            <h2 className="text-2xl font-bold text-white text-right flex-1">{leagueName}</h2>
            <Badge variant="secondary" className="bg-white/95 text-gray-800 hover:bg-white font-semibold">
              {matches.length} مباراة
            </Badge>
          </div>
        </div>
        <div className="p-6 bg-[#1A1A1A]">
          <Tabs defaultValue="matches" dir="rtl" className="w-full">
            <TabsList className="grid w-full grid-cols-2 mb-6 bg-[#262626] border border-gray-700">
              <TabsTrigger value="matches" className="text-base font-semibold text-gray-300 data-[state=active]:bg-gradient-to-r data-[state=active]:from-emerald-400 data-[state=active]:to-cyan-400 data-[state=active]:text-white">
                مباريات اليوم
              </TabsTrigger>
              <TabsTrigger value="standings" className="text-base font-semibold text-gray-300 data-[state=active]:bg-gradient-to-r data-[state=active]:from-emerald-400 data-[state=active]:to-cyan-400 data-[state=active]:text-white">
                ترتيب الدوري
              </TabsTrigger>
            </TabsList>
            <TabsContent value="matches" className="mt-0">
              <div className="bg-[#262626] rounded-xl shadow-lg border border-gray-700 overflow-hidden">
                <LeagueMatchesTable matches={matches} />
              </div>
            </TabsContent>
            <TabsContent value="standings" className="mt-0">
              <div className="bg-[#262626] rounded-xl shadow-lg border border-gray-700 overflow-hidden">
                <LeagueStandings standings={standings} />
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>);

}