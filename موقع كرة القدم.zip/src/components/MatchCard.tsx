import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, Circle } from 'lucide-react';

interface Team {
  id: number;
  name: string;
  logo: string;
}

interface League {
  id: number;
  name: string;
  country: string;
  logo: string;
}

interface Fixture {
  id: number;
}

interface Goals {
  home: number | null;
  away: number | null;
}

interface Status {
  long: string;
  short: string;
  elapsed: number | null;
}

interface MatchCardProps {
  fixture: Fixture;
  league: League;
  teams: {
    home: Team;
    away: Team;
  };
  goals: Goals;
  status: Status;
  date: string;
}

export default function MatchCard({ fixture, league, teams, goals, status, date }: MatchCardProps) {
  const matchTime = new Date(date).toLocaleTimeString('ar-SA', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true
  });

  const isLive = status.short === '1H' || status.short === '2H' || status.short === 'HT' || status.short === 'ET' || status.short === 'P';
  const isFinished = status.short === 'FT' || status.short === 'AET' || status.short === 'PEN';
  const isScheduled = status.short === 'NS' || status.short === 'TBD';

  return (
    <Card className="overflow-hidden hover:shadow-2xl transition-all duration-300 hover:-translate-y-1 border-2 border-gray-700 hover:border-emerald-400 bg-[#262626] card-glow-hover">
      <CardContent className="p-6">
        {/* League Info */}
        <div className="flex items-center gap-2 mb-4 pb-3 border-b border-gray-700">
          <img src={league.logo} alt={league.name} className="w-5 h-5 object-contain" />
          <span className="text-sm font-medium text-gray-200">{league.name}</span>
          {isLive &&
          <Badge variant="destructive" className="mr-auto animate-pulse bg-red-500 text-white">
              <Circle className="w-2 h-2 ml-1 fill-current" />
              مباشر
            </Badge>
          }
          {isFinished &&
          <Badge variant="secondary" className="mr-auto bg-gray-700 text-gray-200">
              انتهت
            </Badge>
          }
        </div>

        {/* Teams and Score */}
        <div className="space-y-4">
          {/* Home Team */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 flex-1">
              <img src={teams.home.logo} alt={teams.home.name} className="w-10 h-10 object-contain" />
              <span className="font-semibold text-white">{teams.home.name}</span>
            </div>
            {!isScheduled &&
            <span className={`text-2xl font-bold min-w-[2rem] text-center ${isLive ? 'text-emerald-400' : 'text-gray-200'}`}>
                {goals.home ?? 0}
              </span>
            }
          </div>

          {/* Away Team */}
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3 flex-1">
              <img src={teams.away.logo} alt={teams.away.name} className="w-10 h-10 object-contain" />
              <span className="font-semibold text-white">{teams.away.name}</span>
            </div>
            {!isScheduled &&
            <span className={`text-2xl font-bold min-w-[2rem] text-center ${isLive ? 'text-emerald-400' : 'text-gray-200'}`}>
                {goals.away ?? 0}
              </span>
            }
          </div>
        </div>

        {/* Match Status/Time */}
        <div className="mt-4 pt-3 border-t border-gray-700 flex items-center justify-center gap-2 text-sm">
          {isScheduled ?
          <>
              <Clock className="w-4 h-4 text-gray-400" />
              <span className="text-gray-300 font-medium">{matchTime}</span>
            </> :
          isLive ?
          <span className="text-emerald-400 font-bold">{status.elapsed}'</span> :

          <span className="text-gray-400 font-medium">الوقت الأصلي</span>
          }
        </div>
      </CardContent>
    </Card>);

}