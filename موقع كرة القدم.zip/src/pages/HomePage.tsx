import { useEffect, useState } from 'react';
import LeagueSection from '@/components/LeagueSection';
import { toast } from 'sonner';

// Arabic league names mapping
const LEAGUE_NAMES_AR: Record<number, string> = {
  140: 'الدوري الإسباني - لاليجا',
  39: 'الدوري الإنجليزي الممتاز',
  61: 'الدوري الفرنسي',
  200: 'الدوري المغربي - البطولة الاحترافية'
};

const LEAGUE_IDS = [140, 39, 61, 200];
const CURRENT_SEASON = new Date().getFullYear();

interface Match {
  fixture: any;
  league: any;
  teams: any;
  goals: any;
  score: any;
}

interface Standing {
  rank: number;
  team: {
    id: number;
    name: string;
    logo: string;
  };
  points: number;
  goalsDiff: number;
  all: {
    played: number;
    win: number;
    draw: number;
    lose: number;
  };
}

interface GroupedMatches {
  [leagueId: number]: Match[];
}

interface LeagueStandings {
  [leagueId: number]: Standing[];
}

export default function HomePage() {
  const [matches, setMatches] = useState<Match[]>([]);
  const [standings, setStandings] = useState<LeagueStandings>({});
  const [loading, setLoading] = useState(true);
  const [standingsLoading, setStandingsLoading] = useState(true);

  useEffect(() => {
    fetchMatches();
    fetchAllStandings();
  }, []);

  const fetchMatches = async () => {
    try {
      setLoading(true);
      const result = await window.ezsite.apis.run({
        path: '__easysite_nodejs__/fetchTodayFixtures.js',
        param: []
      });

      if (result.error) {
        throw new Error(result.error);
      }

      setMatches(result.data || []);

      if (!result.data || result.data.length === 0) {
        toast.info('لا توجد مباريات اليوم للدوريات المحددة');
      }
    } catch (error) {
      console.error('Error fetching matches:', error);
      toast.error('فشل في جلب المباريات. يرجى المحاولة مرة أخرى');
    } finally {
      setLoading(false);
    }
  };

  const fetchAllStandings = async () => {
    try {
      setStandingsLoading(true);
      const standingsData: LeagueStandings = {};

      // Fetch standings for all leagues
      const promises = LEAGUE_IDS.map(async (leagueId) => {
        try {
          const result = await window.ezsite.apis.run({
            path: '__easysite_nodejs__/fetchLeagueStandings.js',
            param: [leagueId, CURRENT_SEASON]
          });

          if (result.data && result.data.length > 0 && result.data[0].league?.standings) {
            standingsData[leagueId] = result.data[0].league.standings[0];
          } else {
            standingsData[leagueId] = [];
          }
        } catch (error) {
          console.error(`Error fetching standings for league ${leagueId}:`, error);
          standingsData[leagueId] = [];
        }
      });

      await Promise.all(promises);
      setStandings(standingsData);
    } catch (error) {
      console.error('Error fetching standings:', error);
      toast.error('فشل في جلب ترتيب الدوريات');
    } finally {
      setStandingsLoading(false);
    }
  };

  // Group matches by league
  const groupedByLeague = matches.reduce<GroupedMatches>((acc, match) => {
    const leagueId = match.league.id;
    if (!acc[leagueId]) {
      acc[leagueId] = [];
    }
    acc[leagueId].push(match);
    return acc;
  }, {});

  return (
    <div className="min-h-screen bg-dark-gradient">
      <div className="container mx-auto px-4 py-8">
        <header className="text-center mb-12">
          <h1 className="text-5xl font-bold text-white mb-4 animate-in fade-in slide-in-from-top duration-700">
            ⚽ 366 score
          </h1>
          <p className="text-xl text-gray-200 animate-in fade-in slide-in-from-top duration-700 delay-150">
            تابع آخر نتائج المباريات وترتيب الدوريات الأوروبية والعربية
          </p>
        </header>

        {loading || standingsLoading ?
        <div className="text-center py-12">
            <div className="inline-block animate-spin rounded-full h-12 w-12 border-b-2 border-emerald-400"></div>
            <p className="mt-4 text-gray-300">
              {loading ? 'جاري تحميل المباريات...' : 'جاري تحميل ترتيب الدوريات...'}
            </p>
          </div> :

        <>
            {/* Display leagues in order */}
            {LEAGUE_IDS.map((leagueId, index) => {
            const leagueMatches = groupedByLeague[leagueId] || [];
            const leagueStandings = standings[leagueId] || [];
            const leagueName = LEAGUE_NAMES_AR[leagueId] || '';
            const leagueLogo = leagueMatches[0]?.league.logo || '';

            // Only show leagues that have either matches or standings
            if (leagueMatches.length === 0 && leagueStandings.length === 0) {
              return null;
            }

            return (
              <LeagueSection
                key={leagueId}
                leagueId={String(leagueId)}
                leagueName={leagueName}
                leagueLogo={leagueLogo}
                matches={leagueMatches}
                standings={leagueStandings}
                isOpen={index === 0} // Open first league by default
              />);

          })}

            {matches.length === 0 && Object.keys(standings).length === 0 &&
          <div className="text-center py-12 text-gray-400">
                لا توجد بيانات متاحة للدوريات المحددة
              </div>
          }
          </>
        }
      </div>
    </div>);

}